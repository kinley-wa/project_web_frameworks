from django.http import HttpResponse
from django.shortcuts import render
# Create your views here.
def home(request):
    context = {'message': "This is my first blog of the year"}
    return render(request, 'blog/templates/blog/home.html')